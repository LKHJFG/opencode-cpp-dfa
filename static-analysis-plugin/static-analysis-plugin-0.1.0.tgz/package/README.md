# Static Analysis Plugin for OpenCode

An OpenCode plugin that provides source code analysis tools for developers.
Built with the official `@opencode-ai/plugin` SDK.

## Tools

### `analyze_file`
Deep analysis of a single source file:
- File statistics (lines, size, language)
- TODO/FIXME/HACK/XXX comment detection
- Long line warnings (>120 chars)
- Trailing whitespace detection
- Long function/block detection

### `list_source_files`
List source files in a directory:
- Shows file names, types, sizes, and detected languages
- Supports 30+ language detection by extension
- Skips hidden files and node_modules by default

### `grep_source`
Search for patterns in source code:
- Case-insensitive search by default
- Configurable file type filters
- Returns file paths, line numbers, and matching content
- Recursive directory search with sensible exclusions

### `code_stats`
Get code statistics for a project:
- Total files, directories, and size
- Breakdown by programming language
- Shows project composition at a glance

## Installation

### From npm (when published)
```json
// opencode.json
{
  "plugin": ["static-analysis-plugin"]
}
```

### From local package
```bash
opencode plugin ./static-analysis-plugin-0.1.0.tgz -g
```

## Development

```bash
# Install dependencies
bun install

# Build
bun run build

# Test
bun test

# Pack for distribution
bun pm pack
```

## Architecture

The plugin follows the OpenCode Plugin pattern:

```
Plugin (async function)
  └─ Hooks
      └─ tool
          ├─ analyze_file
          ├─ list_source_files
          ├─ grep_source
          └─ code_stats
```

Each tool:
- Uses Zod schema for argument validation
- Receives `ToolContext` with session info, directory, and abort signal
- Returns string or `{ output, metadata }` result
- Handles errors gracefully (never throws)
